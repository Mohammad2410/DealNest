import { Notification } from '../types';
import { mockNotifications } from '../mock';

const db: Notification[] = [...mockNotifications];

function delay(ms = 200): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export const notificationService = {
  async getForUser(userId: string): Promise<Notification[]> {
    await delay();
    return db
      .filter(n => n.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  },

  async markRead(id: string): Promise<void> {
    await delay(100);
    const idx = db.findIndex(n => n.id === id);
    if (idx !== -1) db[idx].read = true;
  },

  async markAllRead(userId: string): Promise<void> {
    await delay(200);
    db.forEach(n => { if (n.userId === userId) n.read = true; });
  },

  unreadCount(userId: string): number {
    return db.filter(n => n.userId === userId && !n.read).length;
  },
};
