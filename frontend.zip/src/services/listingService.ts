import { Listing, ListingStatus, ListingCondition } from '../types';
import { mockListings } from '../mock';
import { slugify } from '../lib/utils';

const db = [...mockListings];

export interface ListingFilters {
  query?: string;
  categoryId?: string;
  condition?: ListingCondition;
  location?: string;
  minPrice?: number;
  maxPrice?: number;
  swapOnly?: boolean;
  status?: ListingStatus;
  sellerId?: string;
}

function delay(ms = 300): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export const listingService = {
  async getAll(filters?: ListingFilters): Promise<Listing[]> {
    await delay();
    let results = [...db];
    if (filters?.query) {
      const q = filters.query.toLowerCase();
      results = results.filter(l =>
        l.title.toLowerCase().includes(q) ||
        l.description.toLowerCase().includes(q) ||
        l.brand?.toLowerCase().includes(q) ||
        l.location.toLowerCase().includes(q)
      );
    }
    if (filters?.categoryId) results = results.filter(l => l.categoryId === filters.categoryId);
    if (filters?.condition) results = results.filter(l => l.condition === filters.condition);
    if (filters?.location) results = results.filter(l => l.location.toLowerCase().includes(filters.location!.toLowerCase()));
    if (filters?.minPrice !== undefined) results = results.filter(l => l.price >= filters.minPrice!);
    if (filters?.maxPrice !== undefined) results = results.filter(l => l.price <= filters.maxPrice!);
    if (filters?.swapOnly) results = results.filter(l => l.swapAvailable);
    if (filters?.status) results = results.filter(l => l.status === filters.status);
    if (filters?.sellerId) results = results.filter(l => l.sellerId === filters.sellerId);
    return results.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  },

  async getById(id: string): Promise<Listing | null> {
    await delay(200);
    return db.find(l => l.id === id) || null;
  },

  async getBySlug(slug: string): Promise<Listing | null> {
    await delay(200);
    return db.find(l => l.slug === slug) || null;
  },

  async create(data: Omit<Listing, 'id' | 'slug' | 'createdAt' | 'updatedAt' | 'viewCount' | 'favoriteCount'>): Promise<Listing> {
    await delay(500);
    const listing: Listing = {
      ...data,
      id: `l${Date.now()}`,
      slug: slugify(data.title),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      viewCount: 0,
      favoriteCount: 0,
    };
    db.push(listing);
    return listing;
  },

  async update(id: string, data: Partial<Listing>): Promise<Listing> {
    await delay(400);
    const idx = db.findIndex(l => l.id === id);
    if (idx === -1) throw new Error('Listing not found');
    db[idx] = { ...db[idx], ...data, updatedAt: new Date().toISOString() };
    return db[idx];
  },

  async updateStatus(id: string, status: ListingStatus): Promise<void> {
    await delay(200);
    const idx = db.findIndex(l => l.id === id);
    if (idx !== -1) db[idx].status = status;
  },

  async delete(id: string): Promise<void> {
    await delay(300);
    const idx = db.findIndex(l => l.id === id);
    if (idx !== -1) db.splice(idx, 1);
  },

  async getFeatured(): Promise<Listing[]> {
    await delay(200);
    return db.filter(l => l.status === 'active').slice(0, 8);
  },

  async getRelated(listingId: string, categoryId: string): Promise<Listing[]> {
    await delay(200);
    return db
      .filter(l => l.id !== listingId && l.categoryId === categoryId && l.status === 'active')
      .slice(0, 4);
  },
};
