import { Category } from '../types';
import { mockCategories } from '../mock';

const db = [...mockCategories];

function delay(ms = 200): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export const categoryService = {
  async getAll(): Promise<Category[]> {
    await delay();
    return [...db];
  },
  async getById(id: string): Promise<Category | null> {
    await delay(100);
    return db.find(c => c.id === id) || null;
  },
  async getBySlug(slug: string): Promise<Category | null> {
    await delay(100);
    return db.find(c => c.slug === slug) || null;
  },
};
