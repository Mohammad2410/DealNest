import { Favorite } from '../types';

const db: Favorite[] = [
  { userId: 'u2', listingId: 'l2', createdAt: '2026-08-13T08:00:00Z' },
  { userId: 'u2', listingId: 'l4', createdAt: '2026-08-09T08:00:00Z' },
  { userId: 'u2', listingId: 'l14', createdAt: '2026-08-14T08:00:00Z' },
];

function delay(ms = 150): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export const favoriteService = {
  async getForUser(userId: string): Promise<string[]> {
    await delay();
    return db.filter(f => f.userId === userId).map(f => f.listingId);
  },

  async toggle(userId: string, listingId: string): Promise<boolean> {
    await delay();
    const idx = db.findIndex(f => f.userId === userId && f.listingId === listingId);
    if (idx !== -1) {
      db.splice(idx, 1);
      return false;
    } else {
      db.push({ userId, listingId, createdAt: new Date().toISOString() });
      return true;
    }
  },

  isFavorited(userId: string, listingId: string): boolean {
    return db.some(f => f.userId === userId && f.listingId === listingId);
  },
};
