import { Offer, OfferStatus, OfferHistoryEntry } from '../types';
import { mockOffers } from '../mock';

const db = [...mockOffers];

function delay(ms = 300): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export const offerService = {
  async getByListing(listingId: string): Promise<Offer[]> {
    await delay();
    return db.filter(o => o.listingId === listingId);
  },

  async getById(id: string): Promise<Offer | null> {
    await delay(200);
    return db.find(o => o.id === id) || null;
  },

  async getForUser(userId: string): Promise<{ sent: Offer[]; received: Offer[] }> {
    await delay();
    return {
      sent: db.filter(o => o.buyerId === userId),
      received: db.filter(o => o.sellerId === userId),
    };
  },

  async create(data: {
    listingId: string;
    buyerId: string;
    sellerId: string;
    amount: number;
    message?: string;
  }): Promise<Offer> {
    await delay(500);
    const entry: OfferHistoryEntry = {
      id: `oh${Date.now()}`,
      amount: data.amount,
      message: data.message,
      fromUserId: data.buyerId,
      type: 'offer',
      createdAt: new Date().toISOString(),
    };
    const offer: Offer = {
      id: `o${Date.now()}`,
      ...data,
      status: 'pending',
      history: [entry],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    db.push(offer);
    return offer;
  },

  async counter(offerId: string, fromUserId: string, amount: number, message?: string): Promise<Offer> {
    await delay(400);
    const idx = db.findIndex(o => o.id === offerId);
    if (idx === -1) throw new Error('Offer not found');
    const entry: OfferHistoryEntry = {
      id: `oh${Date.now()}`,
      amount,
      message,
      fromUserId,
      type: 'counter',
      createdAt: new Date().toISOString(),
    };
    db[idx] = {
      ...db[idx],
      amount,
      status: 'countered',
      history: [...db[idx].history, entry],
      updatedAt: new Date().toISOString(),
    };
    return db[idx];
  },

  async accept(offerId: string, fromUserId: string): Promise<Offer> {
    await delay(400);
    const idx = db.findIndex(o => o.id === offerId);
    if (idx === -1) throw new Error('Offer not found');
    const entry: OfferHistoryEntry = {
      id: `oh${Date.now()}`,
      amount: db[idx].amount,
      fromUserId,
      type: 'accepted',
      createdAt: new Date().toISOString(),
    };
    db[idx] = {
      ...db[idx],
      status: 'accepted',
      history: [...db[idx].history, entry],
      updatedAt: new Date().toISOString(),
    };
    return db[idx];
  },

  async reject(offerId: string, fromUserId: string): Promise<Offer> {
    await delay(400);
    const idx = db.findIndex(o => o.id === offerId);
    if (idx === -1) throw new Error('Offer not found');
    const entry: OfferHistoryEntry = {
      id: `oh${Date.now()}`,
      amount: db[idx].amount,
      fromUserId,
      type: 'rejected',
      createdAt: new Date().toISOString(),
    };
    db[idx] = {
      ...db[idx],
      status: 'rejected',
      history: [...db[idx].history, entry],
      updatedAt: new Date().toISOString(),
    };
    return db[idx];
  },

  async withdraw(offerId: string): Promise<void> {
    await delay(300);
    const idx = db.findIndex(o => o.id === offerId);
    if (idx !== -1) {
      db[idx].status = 'withdrawn';
      db[idx].updatedAt = new Date().toISOString();
    }
  },
};
