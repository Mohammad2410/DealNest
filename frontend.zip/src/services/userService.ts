import { User } from '../types';
import { mockUsers } from '../mock';

const db = [...mockUsers];

function delay(ms = 200): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export const userService = {
  async getById(id: string): Promise<User | null> {
    await delay();
    return db.find(u => u.id === id) || null;
  },
  async getAll(): Promise<User[]> {
    await delay();
    return [...db];
  },
  async update(id: string, data: Partial<User>): Promise<User> {
    await delay(400);
    const idx = db.findIndex(u => u.id === id);
    if (idx === -1) throw new Error('User not found');
    db[idx] = { ...db[idx], ...data };
    return db[idx];
  },
};
