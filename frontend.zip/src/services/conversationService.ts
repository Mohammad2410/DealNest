import { Conversation, Message, MessageType } from '../types';
import { mockConversations } from '../mock';

const db: Conversation[] = [...mockConversations];

function delay(ms = 300): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export const conversationService = {
  async getForUser(userId: string): Promise<Conversation[]> {
    await delay();
    return db
      .filter(c => c.participants.includes(userId))
      .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  },

  async getById(id: string): Promise<Conversation | null> {
    await delay(200);
    return db.find(c => c.id === id) || null;
  },

  async getByListing(listingId: string, userId: string): Promise<Conversation | null> {
    await delay(200);
    return db.find(c => c.listingId === listingId && c.participants.includes(userId)) || null;
  },

  async getOrCreate(listingId: string, participants: [string, string]): Promise<Conversation> {
    await delay(300);
    const existing = db.find(c =>
      c.listingId === listingId &&
      participants.every(p => c.participants.includes(p))
    );
    if (existing) return existing;
    const conversation: Conversation = {
      id: `c${Date.now()}`,
      listingId,
      participants,
      messages: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      unreadCount: { [participants[0]]: 0, [participants[1]]: 0 },
    };
    db.push(conversation);
    return conversation;
  },

  async sendMessage(conversationId: string, senderId: string, content: string, type: MessageType = 'text', offerAmount?: number): Promise<Message> {
    await delay(300);
    const idx = db.findIndex(c => c.id === conversationId);
    if (idx === -1) throw new Error('Conversation not found');
    const message: Message = {
      id: `m${Date.now()}`,
      conversationId,
      senderId,
      content,
      type,
      offerAmount,
      createdAt: new Date().toISOString(),
    };
    db[idx].messages.push(message);
    db[idx].lastMessage = message;
    db[idx].updatedAt = new Date().toISOString();
    // Increment unread for other participants
    db[idx].participants.forEach(p => {
      if (p !== senderId) {
        db[idx].unreadCount[p] = (db[idx].unreadCount[p] || 0) + 1;
      }
    });
    return message;
  },

  async markRead(conversationId: string, userId: string): Promise<void> {
    await delay(100);
    const idx = db.findIndex(c => c.id === conversationId);
    if (idx !== -1) db[idx].unreadCount[userId] = 0;
  },

  totalUnread(userId: string): number {
    return db
      .filter(c => c.participants.includes(userId))
      .reduce((sum, c) => sum + (c.unreadCount[userId] || 0), 0);
  },
};
