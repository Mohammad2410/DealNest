import { Transaction, TransactionStatus } from '../types';
import { mockTransactions } from '../mock';
import { PLATFORM_FEE } from '../constants';

const db: Transaction[] = [...mockTransactions];

function delay(ms = 300): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

const TIMELINE_STEPS = [
  { status: 'offer-accepted' as TransactionStatus, label: 'Offer Accepted' },
  { status: 'transaction-created' as TransactionStatus, label: 'Transaction Created' },
  { status: 'seller-preparing' as TransactionStatus, label: 'Seller Preparing' },
  { status: 'out-for-delivery' as TransactionStatus, label: 'Out for Delivery' },
  { status: 'delivered' as TransactionStatus, label: 'Delivered' },
  { status: 'completed' as TransactionStatus, label: 'Completed' },
];

export const transactionService = {
  async getForUser(userId: string): Promise<Transaction[]> {
    await delay();
    return db
      .filter(t => t.buyerId === userId || t.sellerId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  },

  async getById(id: string): Promise<Transaction | null> {
    await delay(200);
    return db.find(t => t.id === id) || null;
  },

  async create(data: {
    type: 'sale' | 'swap';
    buyerId: string;
    sellerId: string;
    item: Transaction['item'];
    swapItem?: Transaction['swapItem'];
    agreedPrice: number;
    cashAdjustment?: number;
    offerId?: string;
    deliveryAddress?: string;
  }): Promise<Transaction> {
    await delay(500);
    const now = new Date().toISOString();
    const transaction: Transaction = {
      id: `t${Date.now()}`,
      ...data,
      platformFee: PLATFORM_FEE,
      totalAmount: (data.cashAdjustment ?? data.agreedPrice) + PLATFORM_FEE,
      paymentMethod: 'cash-on-delivery',
      status: 'transaction-created',
      timeline: TIMELINE_STEPS.map((step, i) => ({
        ...step,
        completed: i <= 1,
        timestamp: i <= 1 ? now : undefined,
      })),
      createdAt: now,
      updatedAt: now,
    };
    db.push(transaction);
    return transaction;
  },

  async advanceStatus(id: string): Promise<Transaction> {
    await delay(400);
    const idx = db.findIndex(t => t.id === id);
    if (idx === -1) throw new Error('Transaction not found');
    const tx = db[idx];
    const statusOrder: TransactionStatus[] = [
      'offer-accepted', 'transaction-created', 'seller-preparing',
      'out-for-delivery', 'delivered', 'completed',
    ];
    const currentIdx = statusOrder.indexOf(tx.status);
    if (currentIdx < statusOrder.length - 1) {
      const nextStatus = statusOrder[currentIdx + 1];
      const now = new Date().toISOString();
      db[idx] = {
        ...tx,
        status: nextStatus,
        timeline: tx.timeline.map(step =>
          step.status === nextStatus ? { ...step, completed: true, timestamp: now } : step
        ),
        updatedAt: now,
      };
    }
    return db[idx];
  },
};
