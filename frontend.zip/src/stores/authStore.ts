import { create } from 'zustand';
import { User } from '../types';
import { mockUsers, CURRENT_USER_ID } from '../mock';

interface AuthState {
  currentUser: User | null;
  isAuthenticated: boolean;
  loginModalOpen: boolean;
  loginRedirectPath: string | null;
  openLoginModal: (redirectPath?: string) => void;
  closeLoginModal: () => void;
  login: (userId: string) => void;
  loginWithCredentials: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  currentUser: mockUsers.find(u => u.id === CURRENT_USER_ID) || null,
  isAuthenticated: true,
  loginModalOpen: false,
  loginRedirectPath: null,

  openLoginModal: (redirectPath) =>
    set({ loginModalOpen: true, loginRedirectPath: redirectPath || null }),

  closeLoginModal: () =>
    set({ loginModalOpen: false, loginRedirectPath: null }),

  login: (userId: string) => {
    const user = mockUsers.find(u => u.id === userId);
    set({ currentUser: user || null, isAuthenticated: !!user, loginModalOpen: false });
  },

  loginWithCredentials: async (email: string, _password: string) => {
    // Mock: match by email, accept any password
    await new Promise(r => setTimeout(r, 700));
    const user = mockUsers.find(u => u.email === email);
    if (user) {
      set({ currentUser: user, isAuthenticated: true, loginModalOpen: false });
      return true;
    }
    return false;
  },

  logout: () => set({ currentUser: null, isAuthenticated: false }),
}));
