import { create } from 'zustand';
import { favoriteService } from '../services/favoriteService';

interface FavoriteState {
  favorites: Set<string>;
  loading: boolean;
  loadFavorites: (userId: string) => Promise<void>;
  toggleFavorite: (userId: string, listingId: string) => Promise<void>;
  isFavorited: (listingId: string) => boolean;
}

export const useFavoriteStore = create<FavoriteState>((set, get) => ({
  favorites: new Set(),
  loading: false,

  loadFavorites: async (userId: string) => {
    set({ loading: true });
    const ids = await favoriteService.getForUser(userId);
    set({ favorites: new Set(ids), loading: false });
  },

  toggleFavorite: async (userId: string, listingId: string) => {
    const { favorites } = get();
    const newFavorites = new Set(favorites);
    if (newFavorites.has(listingId)) {
      newFavorites.delete(listingId);
    } else {
      newFavorites.add(listingId);
    }
    set({ favorites: newFavorites });
    await favoriteService.toggle(userId, listingId);
  },

  isFavorited: (listingId: string) => get().favorites.has(listingId),
}));
